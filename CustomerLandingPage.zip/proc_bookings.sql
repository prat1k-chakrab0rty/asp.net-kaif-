﻿CREATE PROCEDURE [dbo].[bookingscrud]
	@serviceId int,
	@userId int,
	@serviceProviderId int,
	@description varchar(max),
	@action varchar(20)


AS BEGIN 

	IF @action = 'Insert'

	BEGIN

		insert into bookings(dateTime, serviceId, userId, serviceProviderId, description, status, rating) 
			values (GETDATE(), @serviceId, @userId, @serviceProviderId, @description, 'P', 0)

	END

END
