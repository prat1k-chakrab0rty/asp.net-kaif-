﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static System.Collections.Specialized.BitVector32;

namespace ruralCompany
{
    public partial class MyBookings : System.Web.UI.Page
    {
        static string cs = ConfigurationManager.ConnectionStrings["rC"].ConnectionString;
        SqlConnection con = new SqlConnection(cs);
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["email"] == null)
                Response.Redirect("CustLogin.aspx");
            else
                bindGridView();
        }

        void bindGridView()
        {
            SqlCommand cmd = new SqlCommand("myBookings", con);
            cmd.CommandText = "myBookings";
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@email", Session["email"]);
            SqlDataAdapter sda = new SqlDataAdapter(cmd);

            DataTable data = new DataTable();
            sda.Fill(data);
            GridView_MyBookings.DataSource = data;
            GridView_MyBookings.DataBind();
        }
    }
}